export class Item {
	//id: number;
    nombre : string;
    precio : string;
    unidades : string;
    subtotal: string;
    url: string;
}